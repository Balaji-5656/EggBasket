import React, { useState,useRef,useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import Register from "../pages/Register";
import SignIn from "../pages/SignIn";

function Navbar() {
  const [showSignIn, setShowSignIn] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const navigate = useNavigate();

  const [showProfile, setShowProfile] = useState(false);
  const profileRef = useRef(null);
  const [loginHover, setLoginHover] = useState(false);
  const [registerHover, setRegisterHover] = useState(false);
 

  // Get logged in user
  const user = JSON.parse(localStorage.getItem("user"));

  const linkStyle = {
    margin: "0 0.5rem",
    padding: "0.4rem 1rem",
    textDecoration: "none",
    color: "#333",
    fontWeight: 400,
    border: "0.5px solid #0d0d0dff",
    borderRadius: "20px",
    transition: "all 0.3s ease",
  };

  const titleStyle = {
    color: "#FF6F00",
    fontSize: "1.8rem",
    fontWeight: 700,
    textDecoration: "none",
    fontFamily: "Arial, sans-serif",
    transition: "color 0.2s, transform 0.2s",
  };
useEffect(() => {
  const handleClickOutside = (event) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target)
    ) {
      setShowProfile(false);
    }
  };

  document.addEventListener(
    "mousedown",
    handleClickOutside
  );

  return () => {
    document.removeEventListener(
      "mousedown",
      handleClickOutside
    );
  };
}, []);
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    alert("👋 Logged out successfully!");

    navigate("/");
window.location.reload();
  };

  return (
    <>
      <nav
        style={{
          padding: "1rem 2rem",
          background: "#fff",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          boxShadow: "0 2px 10px rgba(0,0,0,0.08)",
          position: "sticky",
          top: 0,
          zIndex: 1000,
        }}
      >
        {/* Left Side */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "2rem",
          }}
        >
          <Link
            to="/"
            style={titleStyle}
            onMouseEnter={(e) => {
              e.target.style.color = "#FFA000";
              e.target.style.transform = "scale(1.05)";
            }}
            onMouseLeave={(e) => {
              e.target.style.color = "#FF6F00";
              e.target.style.transform = "scale(1)";
            }}
          >
            EggBasket🥚
          </Link>

          <div style={{ display: "flex" }}>
            <Link to="/" style={linkStyle}>
              Home
            </Link>

            <Link to="/shop" style={linkStyle}>
              Shop
            </Link>

            <Link to="/cart" style={linkStyle}>
              Cart
            </Link>

            <Link to="/contact" style={linkStyle}>
              Contact
            </Link>
          </div>
        </div>

        {/* Right Side */}
        <div
          style={{
            display: "flex",
            gap: "1rem",
            alignItems: "center",
          }}
        >
          {user ? (
           <div
  ref={profileRef}
  style={{ position: "relative" }}
>
  <div
  onClick={() => setShowProfile(!showProfile)}
  style={{
    ...linkStyle,
    cursor: "pointer",
    fontWeight: "bold",
    border: "1px solid #FF6F00",
  }}
>
  👤 Profile
</div>

  {showProfile && (
    <div
      style={{
        position: "absolute",
        top: "50px",
        right: 0,
        width: "250px",
        background: "#fff",
        borderRadius: "10px",
        boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
        padding: "20px",
        zIndex: 2000,
      }}
    >
      <h3 style={{ margin: 0 }}>
        Hello {user.name}
      </h3>

      <p style={{ color: "#666" }}>
        {user.phone}
      </p>

      <hr />

      <div
        style={menuItemStyle}
        onClick={() => navigate("/my-orders")}
      >
         Orders
      </div>

      <div
        style={menuItemStyle}
        onClick={() => navigate("/wishlist")}
      >
         Wishlist
      </div>

      <div
        style={menuItemStyle}
        onClick={() =>
          navigate("/saved-addresses")
        }
      >
         Saved Addresses
      </div>

      <div
        style={menuItemStyle}
        onClick={() => navigate("/profile")}
      >
         Edit Profile
      </div>

      <hr />

      <div
        style={{
          ...menuItemStyle,
          color: "red",
          fontWeight: "bold",
        }}
        onClick={handleLogout}
      >
         Logout
      </div>
    </div>
  )}
</div>
          ) : (
            <>
              {/* Login */}
              <div
                onClick={() => setShowSignIn(true)}
                onMouseEnter={() => setLoginHover(true)}
                onMouseLeave={() => setLoginHover(false)}
                style={{
                  ...linkStyle,
                  cursor: "pointer",
                  border: "1px solid #4CAF50",
                  backgroundColor: loginHover
                    ? "#4CAF50"
                    : "#fff",
                  color: loginHover ? "#fff" : "#333",
                  transform: loginHover
                    ? "scale(1.05)"
                    : "scale(1)",
                }}
              >
                Login
              </div>

              {/* Register */}
              <div
                onClick={() => setShowRegister(true)}
                onMouseEnter={() => setRegisterHover(true)}
                onMouseLeave={() => setRegisterHover(false)}
                style={{
                  ...linkStyle,
                  cursor: "pointer",
                  border: "1px solid #2196F3",
                  backgroundColor: registerHover
                    ? "#2196F3"
                    : "#fff",
                  color: registerHover ? "#fff" : "#333",
                  transform: registerHover
                    ? "scale(1.05)"
                    : "scale(1)",
                }}
              >
                Register
              </div>
            </>
          )}
        </div>
      </nav>

      {/* Sign In Panel */}
      <SignIn
        isOpen={showSignIn}
        onClose={() => setShowSignIn(false)}
      />

      {/* Register Panel */}
      <Register
        isOpen={showRegister}
        onClose={() => setShowRegister(false)}
        onSwitchToSignin={() => {
          setShowRegister(false);
          setShowSignIn(true);
        }}
      />
    </>
  );
}
const menuItemStyle = {
  padding: "12px",
  cursor: "pointer",
  fontSize: "16px",
  borderRadius: "8px",
  transition: "0.3s",
};

export default Navbar;