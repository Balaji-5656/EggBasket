import React from "react";
import { useNavigate } from "react-router-dom";

function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div style={{ padding: "2rem" }}>
      <h1>👨‍💼 Admin Dashboard</h1>

      <h3>Welcome Admin!</h3>

      <div
        style={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          marginTop: "30px",
        }}
      >
        <button
          onClick={() => navigate("/admin/add-product")}
          style={buttonStyle}
        >
          ➕ Add Products
        </button>

       <button
  onClick={() =>
    navigate("/admin/orders")
  }
  style={buttonStyle}
>
  📦 View Orders
</button>

        <button
          style={buttonStyle}
        >
          ✏️ Edit Products
        </button>

        <button
          style={buttonStyle}
        >
          🗑️ Delete Products
        </button>
      </div>
    </div>
  );
}

const buttonStyle = {
  padding: "15px 25px",
  background: "#FF6F00",
  color: "#fff",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  fontWeight: "bold",
  fontSize: "16px",
};

export default AdminDashboard;