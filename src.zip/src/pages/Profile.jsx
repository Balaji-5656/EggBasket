import React, { useState } from "react";

function Profile() {
  const user = JSON.parse(localStorage.getItem("user"));

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...user,
      name: formData.name,
      phone: formData.phone,
    };

    localStorage.setItem(
      "user",
      JSON.stringify(updatedUser)
    );

    alert("✅ Profile Updated Successfully!");

    window.location.reload();
  };

  return (
    <div
      style={{
        maxWidth: "500px",
        margin: "40px auto",
        padding: "30px",
        border: "1px solid #ddd",
        borderRadius: "10px",
        background: "#fff",
      }}
    >
      <h1>👤 My Profile</h1>

      <div style={{ marginTop: "20px" }}>
        <label>Name</label>

        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>

      <div>
        <label>Email</label>

        <input
          type="email"
          value={formData.email}
          readOnly
          style={{
            ...inputStyle,
            background: "#f5f5f5",
          }}
        />
      </div>

      <div>
        <label>Phone Number</label>

        <input
          type="text"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>

      <button
        onClick={handleSave}
        style={{
          width: "100%",
          padding: "12px",
          marginTop: "20px",
          background: "#FF6F00",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          fontWeight: "bold",
        }}
      >
        Save Changes
      </button>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  marginBottom: "20px",
  border: "1px solid #ddd",
  borderRadius: "5px",
  boxSizing: "border-box",
};

export default Profile;